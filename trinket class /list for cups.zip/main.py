



# Convert cups to grams
#1 cup -> gms
#how much does ur 1 cup holds-› 50 gms
#cups_to_gms-->>> convert 5 cups = __ gms?
#5cups * 50gm
def cups_to_grams (cups, conversion_rate):
  return cups *conversion_rate

# Convert tablespoons to teaspoons
def tablespoons_to_teaspoons (tablespoons):
  return tablespoons * 3 # 1 tablespoon =3 teaspoons

# Convert grams to cups
def grams_to_cups (grams, conversion_rate):
  return grams / conversion_rate

# Main program
def recipe_converter () :
  print("\nwelcome to the Recipe Converter!")
  while True:
    print("InChoose an option:")
    print("1. Convert cups to grams")
    print("2. Convert tablespoons to teaspoons")
    print("3. Convert grams to cups")
    print("4. Exit")
    choice = int(input("Enter your choice (1-4): "))
    if choice == 1:
      cups = float(input("Enter the number of cups: "))
      conversion_rate = float(input("Enter the grams per cup for the ingredient: "))
      result = cups_to_grams (cups, conversion_rate)
      print("Result: {} grams". format (result))

    elif choice == 2:
      tablespoons = int(input("Enter the number of tablespoons: "))
      result = tablespoons_to_teaspoons (tablespoons)
      print("Result: {} teaspoons". format(result))


    elif choice == 3:
      grams = int(input("How many grams do you have:"))
      conversion_rate = int(input("Enter the grams per cup: "))
      result = grams_to_cups (grams,conversion_rate)
      print("Result: {} cups". format(result))
      
    elif choice==4:
      print("App. GoodBye")
      break
    else:
      print("eliter the valid option between 1-5")
      

recipe_converter()