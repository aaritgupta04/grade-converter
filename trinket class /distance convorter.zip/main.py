def km_m (Kilometers):
  return Kilometers*1000

def m_cm(Meters):
  return meters*100
  
def cm_mm(Centimeter):
  return Centimeter*10
  
while True:
  print("InChoose an option:")
  print("1. Convert km to m")
  print("2. Convert m to cm")
  print("3. Convert cm to mm")
  print("4. Exit")
  choice = int(input("Enter your choice (1-4): "))
    
  if choice ==1:
    km=float(input("enter the kilometer"))
    result=km_m(km)
    print("Result: {} meters". format (result))
      
      
  elif choice==2:
    m=float(input("enter the meter"))
    result=m_cm(m)
    print("Result: {} centimeter". format (result))
      
  elif choice==3:
    cm=float(input("enter the cm"))
    result=cm_mm(cm) 
    print("Result:{} centimeter". format (result))
      
      
  elif choice==4:
    print("App. GoodBye")
    break
  else:
    print("eliter the valid option between 1-5")