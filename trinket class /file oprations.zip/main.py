#writing inside the file

file = open("details.txt","w") #this will open the file
#now we will write in this
#6 functions = open, read, write, readline, readlines, close
file.write("Hello Aarit. \n")
file.write("Where do you go to school. ")


file.close()

#reading the file
file = open("details.txt","r") #read mode
content = file.read() #read everything from the file
print(content)
file.close()
print("--")

#readline
file = open("details.txt", "r")
content = file.readline() #read only line of statement
print(content)

file.close()


print("---------")

#appending in the file
file = open("details.txt", "a")
file.write("My hobby is Coding.")

file.close()

#reading file using WITH statement
with open("details.txt", "r") as file:
  print(file.readlines)
  