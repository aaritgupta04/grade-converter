dictionary={}
 
while True:

  print("\nMini Dictionary App: ")
  print ("1. Add/Update the lem")
  print("2. Retrieve a word's definition")
  print ("3. Delete the word")

  print("4. View all the words")
  print("5. Exit")
  
  
  choice= int(input("Choose an option (1-5) : "))


  if choice==1:
    word = input("Enter the word: ").strip()
    definition = input("Enter the definition: ").strip()  
    dictionary[word]=definition
    print("Word {} got added Successfully!". format(word))
    
  if choice==2:
    word=input ("Enter the word to retrive: ").strip() 
    if word in dictionary:
      print("{}: {}".format(word, dictionary [word]))
    else:
      print("This word doesnt exists in the dictionary.")
    
  if choice==3:
    word=input ("Enter the word to delete: "). strip() 
    if word in dictionary: 
      del dictionary[word]
      print ("The word {} got deleted".format(word))
    else:
      print("This word doesnt exists in the dictionary.")
    
  if choice==4:
    if dictionary:
      print("InWords in the dictionary: ")
      for word in dictionary:
        print("{} : {} ".format(word, dictionary[word]))
    else:
      print("the dictionary is empty")
      
  if choice==5:
    print("Exiting the Mini Dictionary App. GoodBye")
    break
  else:
    print("eliter the valid option between 1-5")